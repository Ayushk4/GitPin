#include "y.tab.h"
#include <stdio.h>
extern int yylex();
extern int yydebug;

int main() {
    yydebug=1;
    yyparse();
}
