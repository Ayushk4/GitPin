#include "ass6_17CS10006_translator.h"
#include "y.tab.h"

extern Quad quad;
void SymbolTable::get_gotos()
{
	//Traverse in all the quads and add all the gotos
	int i;
	for(i = 0;i < quad.quadarray.size(); i++)
	{
		if(quad.quadarray[i].op == o_GOTO || (quad.quadarray[i].op >= o_JLT && quad.quadarray[i].op <= o_JNE) )
		{
			//simple GOTO or Relational Operators
			gotos.insert(atoi(quad.quadarray[i].result.c_str()));
		}
	}
}
void SymbolTable::set_activation_offsets()
{
	//offsets of Parameters and the local variables are to be changed here
	int i,pos,param_size=0;
	for(i=1;i<table.size() && table[i]->var_type == "param";i++)
	{
		// Scan and add sizes of all the parameters
		//table[i]->size = 8;//table[i]->size * 2;
		param_size += table[i]->size;
	}
	//change the offsets of the rest of the variables
	printf("Param Size=%d\n",param_size);
	pos = i;
	for(;i<table.size();i++)
	{
		//Local Variables
		table[i]->offset = param_size - table[i]->size - table[i]->offset - 4;
	}
	for(i=1;i<pos;i++)
	{
		//Params
		// table[i]->offset = param_size - table[i]->offset + table[0]->size + 4;
		table[i]->offset = ((pos-1)*4 - table[i]->offset + table[0]->size + 4)*2;
	}
	//Global Offset
	offset = offset - param_size - table[0]->size + 12;
}

void SymbolTable::generate_prologue(FILE *fp)
{
	fprintf(fp,"\t.text\n\t.globl\t%s\n\t.type\t%s,  @function\n",name.c_str(),name.c_str());
	//print label
	fprintf(fp,"%s:\n",name.c_str());
	//Push rbp and shift current esp to rbp
	//fprintf(fp,"LFB0:\n");
	fprintf(fp,"\tpushq\t%%rbp\n\tmovq\t%%rsp,  %%rbp\t\n");
	//Create space for the local variables
	fprintf(fp,"\tsubq\t$%d, %%rsp\n",offset);
}

void SymbolTable::print_internal_code(FILE *fp)
{
	/*Get quads one by one and start printng their assembly output*/
	int i, noOfParam, i_param;				// Variable for iterating between the function quads
	/*Assign all arrays with their address locations*/
	/*for(i = 1;i < table.size();i++)
	{
		if(table[i]->type!= NULL && table[i]->type->baseType == t_ARRAY)
		{
			fprintf(fp,"#;Array : %s\n",table[i]->name.c_str());
			fprintf(fp,"\tleal\t%d(%%rbp), %%eax\n",table[i]->offset);
			fprintf(fp,"\tmovl\t%%eax, %d(%%rbp)\n",table[i]->offset);
		}
	}*/
	/*Get Quad one by one and then start printing their assembly code*/
	for(i = start_quad; i <= end_quad; i++)
	{
		opcodeType &opx = quad.quadarray[i].op;
		string &arg1x = quad.quadarray[i].arg1;
		string &arg2x = quad.quadarray[i].arg2;
		string &resx = quad.quadarray[i].result;
		int offr,off1,off2;
		fprintf(fp,"#; %d:",i);
		if(search(resx))
		{
			offr = search(resx)->offset;
			fprintf(fp,"res =  %s ",search(resx)->name.c_str());
		}
		if(search(arg1x))
		{
			off1 = search(arg1x)->offset;
			fprintf(fp,"arg1 =  %s ",search(arg1x)->name.c_str());
		}
		if(search(arg2x))
		{
			off2 = search(arg2x)->offset;
			fprintf(fp," arg2 = %s ",search(arg2x)->name.c_str());
		}
		fprintf(fp,"\n");
		if(gotos.find(i)!=gotos.end())
		{
			//Generate Label here
			fprintf(fp," .L%d:\n",i);
		}
		if (opx == o_PLUS){
				// Copy values in eax and edx, add both of them to eax then move it to destination
				fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
				if(arg2x[0]>='0' && arg2x[0]<='9')
					fprintf(fp," \tmovl\t$%s, %%edx\n",arg2x.c_str());
				else
					fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",off2);
				fprintf(fp," \taddl\t%%edx,  %%eax\n");
				fprintf(fp,"\tmovl\t%%eax,  %d(%%rbp)\n",offr);
		}	
		else if (opx == o_MINUS) {
				if(search(resx)->type->baseType == t_CHAR)
				{
					fprintf(fp,"\tmovzbl\t%d(%%rbp),  %%eax\n",off1);
					fprintf(fp,"\tmovzbl\t%d(%%rbp),  %%edx\n",off2);
					fprintf(fp,"\tsubl\t%%edx,  %%eax\n");
					fprintf(fp,"\tmovb\t%%al,  %d(%%rbp)\n",offr);
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
					// Direct Number access
					if(arg2x[0]>='0' && arg2x[0]<='9')
						fprintf(fp," \tmovl\t$%s, %%edx\n",arg2x.c_str());
					else
						fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",off2);
					fprintf(fp,"\tsubl\t%%edx, %%eax\n");
					fprintf(fp,"\tmovl\t%%eax, %d(%%rbp)\n",offr);
				}
			}
			else if (opx == o_MULT) {
				fprintf(fp," \tmovl\t%d(%%rbp),  %%eax\n",off1);
				if(arg2x[0]>='0' && arg2x[0]<='9')
				{
					fprintf(fp," \timull\t$%s,  %%eax, %%eax\n",arg2x.c_str());
					//fprintf(fp,"\timull\t%%ecx\n");
				}
				else
					fprintf(fp,"\timull\t%d(%%rbp),  %%eax\n",off2);
				fprintf(fp,"\tmovl\t%%eax,  %d(%%rbp)\n",offr);
			}
			else if (opx == o_DIV)  {
				fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
				fprintf(fp," \tcltd\n ");
				fprintf(fp," \tidivl\t%d(%%rbp)\n ",off2);
				fprintf(fp," \tmovl\t%%eax, %d(%%rbp)\n",offr);
			}
			else if (opx == o_MOD)  {
				fprintf(fp,"\tmovl\t%d(%%rbp),  %%eax\n",off1);
				fprintf(fp," \tcltd\n");
				fprintf(fp," \tidivl\t%d(%%rbp)\n",off2);
				fprintf(fp," \tmovl\t%%edx, %d(%%rbp)\n",offr);
			}
			else if (opx == o_UMINUS) {
				fprintf(fp," \tmovl\t%d(%%rbp),  %%eax\n",off1);
				fprintf(fp," \tnegl\t%%eax\n ");
				fprintf(fp," \tmovl\t%%eax,  %d(%%rbp)\n ",offr);
			}
			else if (opx == o_COPY)		{
				//Check if the second argument is a constant
				if(arg1x[0]>='0' && arg1x[0]<='9')	//first character is number
				{
					fprintf(fp," \tmovl\t$%s,  %d(%%rbp)\n",arg1x.c_str(),offr);
				}
				else if(arg1x[0] == '\'')
				{
					//Character
					fprintf(fp," \tmovb\t$%d,  %d(%%rbp)\n",(int)arg1x[1],offr);
				}
				else if(search(resx)->type->baseType == t_CHAR)
				{
					fprintf(fp," \tmovzbl\t%d(%%rbp),  %%eax\n",off1);
					fprintf(fp," \tmovb\t%%al,  %d(%%rbp)\n",offr);
				}
				else if(search(resx)->type->baseType == t_PTR)
				{
					fprintf(fp," \tmovq\t%d(%%rbp), %%rax\n",off1);
					fprintf(fp," \tmovq\t%%rax, %d(%%rbp)\n",offr);
				}
				else
				{
					fprintf(fp,"\tmovl\t%d(%%rbp),  %%eax\n",off1);
					fprintf(fp,"\tmovl\t%%eax,  %d(%%rbp)\n",offr);
				}
			}
			else if (opx == o_PARAM)  {
				if(resx[0] == '_')
				{
					//string
					char* temp = (char*)resx.c_str();
					fprintf(fp," \tmovq\t$.STR%d,\t%%rdi\n",atoi(temp+1));
				}
				else if(search(resx)->type->baseType == t_ARRAY)
				{
					//Array
					fprintf(fp," \tleaq\t%d(%%rbp), %%rax\n",offr);
					fprintf(fp," \tpushq\t%%rax\n");
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",offr);
					fprintf(fp," \tpushq\t%%rax\n");
				}
			}
			else if (opx == o_GOTO)  {
				fprintf(fp," \tjmp .L%s\n",resx.c_str());
			}
			else if (opx == o_CALL)  {
				//fprintf(fp, "##arg1x%s\n", arg2x.c_str() );
				if(arg1x == "printi")
				{
					string &resultx = quad.quadarray[i-1].result;
					int offer = search(resultx)->offset;
					fprintf(fp," \tmovl\t%d(%%rbp), %%edi\n",offer);
					fprintf(fp," \tcall\t%s\n",arg1x.c_str());
					noOfParam = atoi(arg2x.c_str());
					for(i_param=0;i_param<noOfParam;i_param++)
						fprintf(fp, " \tpopq\t%%rax\n");
				}
				else if(arg1x == "readi")
				{
					string &resultx = quad.quadarray[i-1].result;
					int offer = search(resultx)->offset;
					fprintf(fp," \tmovq\t%d(%%rbp), %%rdi\n",offer);
					fprintf(fp," \tcall\t%s\n",arg1x.c_str());
					noOfParam = atoi(arg2x.c_str());
					for(i_param=0;i_param<noOfParam;i_param++)
						fprintf(fp, " \tpopq\t%%rax\n");
				}
				else if(arg1x == "prints")
				{
					fprintf(fp," \tcall\t%s\n",arg1x.c_str());
					fprintf(fp," \tmovl\t%%eax, %d(%%rbp)\n",offr);
					fprintf(fp," \tmovl\t$0, %%eax\n");
				}
				else
				{
					fprintf(fp," \tcall\t%s\n",arg1x.c_str());
					fprintf(fp," \tmovl\t%%eax, %d(%%rbp)\n",offr);
					fprintf(fp," \tmovl\t$0, %%eax\n");
					noOfParam = atoi(arg2x.c_str());
					for(i_param=0;i_param<noOfParam;i_param++)
						fprintf(fp, "\tpopq\t%%rax\n");
				}
				
			}
			// If and GOTO
			else if (opx == o_JLT)  {
				if(search(arg1x)->type->baseType == t_CHAR)
				{
					fprintf(fp," \tmovzbl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tcmpb\t%d(%%rbp), %%al\n",off2);
					fprintf(fp," \tjl  .L%s\n",resx.c_str());
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",off2);
					fprintf(fp," \tcmpl\t%%edx, %%eax\n");
					fprintf(fp," \tjl .L%s\n",resx.c_str());
				}
			}
			else if (opx == o_JLE)  {
				if(search(arg1x)->type->baseType == t_CHAR)
				{
					fprintf(fp," \tmovzbl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tcmpb\t%d(%%rbp), %%al\n",off2);
					fprintf(fp," \tjle .L%s\n",resx.c_str());
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",off2);
					fprintf(fp," \tcmpl\t%%edx, %%eax\n");
					fprintf(fp," \tjle .L%s\n",resx.c_str());
				}
			}
			else if (opx == o_JGT)  {
				if(search(arg1x)->type->baseType == t_CHAR)
				{
					fprintf(fp," \tmovzbl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tcmpb\t%d(%%rbp), %%al\n",off2);
					fprintf(fp," \tjg .L%s\n",resx.c_str());
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",off2);
					fprintf(fp," \tcmpl\t%%edx, %%eax\n");
					fprintf(fp," \tjg .L%s\n",resx.c_str());
				}
			}
			else if (opx == o_JGE)
			{
				if(search(arg1x)->type->baseType == t_CHAR)
				{
					fprintf(fp," \tmovzbl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tcmpb\t%d(%%rbp), %%al\n",off2);
					fprintf(fp," \tjge .L%s\n",resx.c_str());
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",off2);
					fprintf(fp,"\tcmpl\t%%edx, %%eax\n");
					fprintf(fp," \tjge .L%s\n",resx.c_str());
				}
			}
			else if (opx == o_JE)  {
				if(search(arg1x)->type->baseType == t_CHAR)
				{
					fprintf(fp," \tmovzbl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tcmpb\t%d(%%rbp), %%al\n",off2);
					fprintf(fp," \tje .L%s\n",resx.c_str());
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp,"\tmovl\t%d(%%rbp), %%edx\n",off2);
					fprintf(fp," \tcmpl\t%%edx,  %%eax\n");
					fprintf(fp,"\tje  .L%s\n",resx.c_str());
				}
			}
			else if (opx == o_JNE)
			{
				if(search(arg1x)->type->baseType == t_CHAR)
				{
					fprintf(fp," \tmovzbl\t%d(%%rbp),  %%eax\n",off1);
					fprintf(fp," \tcmpb\t%d(%%rbp),  %%al\n",off2);
					fprintf(fp," \tjne .L%s\n",resx.c_str());
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off1);
					fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",off2);
					fprintf(fp," \tcmpl\t%%edx,  %%eax\n");
					fprintf(fp,"  \tjne .L%s\n",resx.c_str());
				}
			}
			else if (opx == o_ADDR)  {
				fprintf(fp," \tleaq\t%d(%%rbp), %%rax\n",off1);
				fprintf(fp," \tmovq\t%%rax, %d(%%rbp)\n",offr);
			}
			else if (opx == o_LDEREF)  {
				fprintf(fp," \tmovq\t%d(%%rbp), %%rax\n",off1);
				fprintf(fp," \tmovl\t%d(%%rbp), %%edx\n",offr);
				fprintf(fp," \tmovl\t%%edx,  (%%rax)\n");
			}
			else if (opx == o_RDEREF)  {
				fprintf(fp," \tmovq\t%d(%%rbp),  %%rax\n",off1);
				fprintf(fp,"\tmovl\t(%%rax),  %%eax\n");
				fprintf(fp," \tmovl\t%%eax, %d(%%rbp)\n",offr);
			}
			else if (opx == o_RINDEX)  {
				// Get Address, subtract offset, get memory
				fprintf(fp," \tleaq\t%d(%%rbp), %%rdx\n",off1);
				fprintf(fp," \taddq\t%d(%%rbp), %%rdx\n",off2);
				if(search(resx)->type->baseType == t_CHAR)
				{
					fprintf(fp," \tmovzbl\t(%%rdx),  %%eax\n");
					fprintf(fp," \tmovb\t%%al, %d(%%rbp)\n",offr);
				}
				else
				{
					fprintf(fp," \tmovl\t(%%rdx), %%eax\n");
					fprintf(fp," \tmovl\t%%eax,   %d(%%rbp)\n",offr);
				}
			}
			else if (opx == o_LINDEX)  {
				// Get Address, subtract offset, get memory
				fprintf(fp," \tleaq\t%d(%%rbp), %%rdx\n",offr);
				fprintf(fp," \taddq\t%d(%%rbp), %%rdx\n",off1);
				if(search(resx)->type->baseType == t_CHAR)
				{
					fprintf(fp," \tmovzbl\t%d(%%rbp), %%eax\n",off2);
					fprintf(fp," \tmovb\t%%al, (%%rdx)\n");
				}
				else
				{
					fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",off2);
					fprintf(fp," \tmovl\t%%eax, (%%rdx)\n");
				}
			}
			else if (opx == o_RET) {
				fprintf(fp," \tmovl\t%d(%%rbp), %%eax\n",offr);
				generate_epilogue(fp);
			}
	
	}
}

void SymbolTable::generate_epilogue(FILE *fp)
{
	//Restore the stack pointer and the base pointer
	fprintf(fp,"#;  Func Epilogue\n");
	fprintf(fp," \taddq\t$%d,  %%rsp\n",offset);
	fprintf(fp,"\tmovq\t%%rbp,  %%rsp\n");
	fprintf(fp," \tpopq\t%%rbp\n");
	fprintf(fp," \tret\n");
	fprintf(fp,"#;  Func End\n");
}



