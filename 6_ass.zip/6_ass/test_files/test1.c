int main()
{
   int row, c, n, temp;
 
   prints("Enter the number of rows in pyramid of stars you wish to see\n");
   readi(&n);
 
   temp = n;
 
   for ( row = 1 ; row <= n ; row++ )
   {
      for ( c = 1 ; c < temp ; c++ )
         prints(" ");
 
      temp--;
 
      for ( c = 1 ; c <= 2*row - 1 ; c++ )
         prints("*");
 
      prints("\n");
   }
 
   return 0;
}