int factorial(int n)
{
  int c;
  int result = 1;
 
  for (c = 1; c <= n; c++)
    result = result * c;
 
  return result;
}
int factorial_recur(int n)
{
  int a;
  if (n == 0)
    return 1;
  else
    {
      a = factorial_recur(n-1);
      a = a*n;
      return a;
    }
    return 1;
}
int main()
{
  int n=5;
  int f;
  int k=0;
  prints("Enter an integer to find factorial by recursive method\n");
  readi(&n); 
  if (n < 0)
    //k++;
    prints("Negative integers are not allowed.\n");
  else
  {
    f = factorial_recur(n);
    prints("The factorial is: ");
    printi(f);
    prints("\n");
  }
 
  return 0;
}
