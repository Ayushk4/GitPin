int findgcd(int x,int y)
{
    int a1,a2;
    while(x!=y)
    {
        if(x>y)
        {
            a1 = findgcd(x-y,y);
            return a1;
        }
        else
        {
            a2 = findgcd(x,y-x);
            return a2;
        }
    }
    return x;
}

int main(){
    int n1,n2,gcd;
    prints("Enter two numbers to find GCD: ");
    readi(&n1);
    readi(&n2);
    gcd = findgcd(n1,n2);
    prints("GCD of the two numbers is ");
    printi(gcd);
    prints("\n");
    return 0;
}

