int main()
{
   int c, first, last, middle, n, search, array[100],flag=0,swap,d;
 
   prints("Enter number of elements for binary searching\n");
   readi(&n);
   prints("Enter integers\n");
 
   for (c = 0; c < n; c++)
      {
         int a;
         readi(&a);
         array[c] = a;
      }
 
   prints("Enter value to find\n");
   readi(&search);
   int k1,k2;
   k1 = n-1;
   for (c = 0 ; c < k1; c++)
   {
      k2 = n - c - 1;
      for (d = 0 ; d < k2; d++)
      {
         int a1;
         a1 = d+1;
         if (array[d] > array[a1]) 
         {
            swap       = array[d];
            array[d]   = array[a1];
            array[a1] = swap;
         }
      }
   }

   prints("Sorted Array: \n[");
   for(c = 0; c < n; c++)
   {
      printi(array[c]);
      prints(", ");
   }   
   prints("]\n");

   first = 0;
   last = n - 1;
   middle = (first+last)/2;
   
   while (first <= last && flag==0) {
      if (array[middle] < search)
         first = middle + 1;    
      else if (array[middle] == search) {
         prints("Number found at location: ");
         printi(middle+1);
         flag=1;
      }
      else
         last = middle - 1;
 
      middle = (first + last)/2;
   }
   if (first > last)
      prints("Not found!");
   prints("\n");
      
   return 0;   
}