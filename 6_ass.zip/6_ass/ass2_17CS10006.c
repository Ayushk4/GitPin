#include "myl.h"
#define BUFFER 20

int prints(char *s)
{
	int len = 0, i = 0;
	while(s[i] != '\0')
	{
		len++;
		i++;
	}
	__asm__ __volatile__ (
	"movq $1, %%rax \n\t"
	"movq $1, %%rdi \n\t"
	"syscall \n\t"
	:
	:"S"(s), "d"(len)
	);
	return len;
}

int printi(int n)
{
	char buff[BUFFER];	
	int i = 0, j = 0;
	if(n == 0)
	{
		buff[i++] = '0';
	}
	else if(n < 0)
	{
		buff[i++] = '-';
		n = -n;
		j = 1;
	}
	while(n)
	{
		int r = n % 10;
		buff[i++] = r + '0';
		n = n / 10;
	}
	int k = i - 1;
	while(k > j)
	{
		char temp = buff[k];
		buff[k] = buff[j];
		buff[j] = temp;
		k--;
		j++;
	}
	__asm__ __volatile__ (
	"movl $1, %%eax \n\t"
	"movq $1, %%rdi \n\t"
	"syscall \n\t"
	:
	:"S"(buff), "d"(i)
	);
	return i;
}

int readi(int *eP)
{
	char buff[BUFFER];
	int len, neg = 0, i = 0, number = 0;
	__asm__ __volatile__ (
	"movl $0, %%eax \n\t"
	"movq $1, %%rdi \n\t"
	"syscall \n\t"
	:"=rax"(len)
	:"S"(buff), "d"(BUFFER)
	);
	len--;
	if(len <= 0)
	{
		*eP = 0;
		return ERR;
	}
	if(buff[i] == '-')
	{
		neg = 1;
		i++;
	}
	while(i < len)
	{
		if(buff[i] >= '0' && buff[i] <= '9')
		{
			number = number * 10 + (buff[i] - '0');
		}
		else
		{
			*eP = 0;
			return ERR;
		}
		i++;
	}
	if(neg == 1)
		number = -number;
	*eP = number;
	return OK;
}

int readf(float *f)
{
	char buff[BUFFER];
	int len, neg = 0, i = 0, decimal = 0;
	double number = 0.0, count=10.0;
	__asm__ __volatile__ (
	"movl $0, %%eax \n\t"
	"movq $1, %%rdi \n\t"
	"syscall \n\t"
	:"=rax"(len)
	:"S"(buff), "d"(BUFFER)
	);
	len--;
	if(len <= 0)
	{
		return ERR;
	}
	if(buff[i] == '-')
	{
		neg = 1;
		i++;
	}
	
	while(i < len)
	{
		if(buff[i] >= '0' && buff[i] <= '9' && decimal == 0)
		{
			number = number * 10 + (buff[i] - '0');
		}
		else if(buff[i] >= '0' && buff[i] <= '9' && decimal == 1)
		{
			number = (number * count + (buff[i] - '0')*1.0) / count;
			count*=10.0;
		}
		else if(buff[i] == '.' && decimal == 0)
		{
			decimal = 1;
		}
		else
		{
			return ERR;
		}
		i++;
	}
	if(neg == 1)
		number = -number;
	*f = number;
	return OK;
}

int printd(float num)
{
	double f = num;
	int i = 0, j = 0;
	char buff[BUFFER];
	if(f < 0)
	{
		buff[i++] = '-';
		f = -f;
		j = 1;
	}
	int n = (int) f;
	f = f - n;
	if(n==0){
		buff[i++]='0';
	}
	while(n)
	{
		int r = n % 10;
		buff[i++] = r + '0';
		n = n / 10;
	}
	int k = i - 1;
	while(k > j)
	{
		char temp = buff[k];
		buff[k] = buff[j];
		buff[j] = temp;
		k--;
		j++;
	}
	// while(i>0)
	// {
	// 	f *= 10.0;
	// 	m = (m * 10) + (int) f;
	// 	f = f - (int) f;
	// 	i--;
	// }
	buff[i++] = '.';
	f = f * 1000000;
	int ipart  = (int)f;
	int temp = ipart;
	int count = 0;
	while(temp>0){
		temp/=10;
		count++;
	}
	temp = 6 - count;
	while(temp>0){
		buff[i++]='0';
		temp--;
	}
	j=i;
	while(ipart)
	{
		int r = ipart % 10;
		buff[i++] = r + '0';
		ipart = ipart / 10;
	}
	k = i - 1;
	while(k > j)
	{
		char temp = buff[k];
		buff[k] = buff[j];
		buff[j] = temp;
		k--;
		j++;
	}
	__asm__ __volatile__ (
	"movl $1, %%eax \n\t"
	"movq $1, %%rdi \n\t"
	"syscall \n\t"
	:
	:"S"(buff), "d"(i)
	);
	return i;
}
